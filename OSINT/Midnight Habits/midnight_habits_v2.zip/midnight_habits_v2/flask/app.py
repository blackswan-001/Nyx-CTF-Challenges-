from flask import Flask, request, jsonify
import hashlib

app = Flask(__name__)

# Credentials stored server-side only — never sent to browser
VALID_EMAIL = "n.hale@nyxresearch.org"
VALID_PASSWORD = "Blackcoffee!_2021"
FLAG = "NYX{pa55w0rds_4r3_p30pl3_7oo}"

# Rate limiting — simple in-memory attempt counter
from collections import defaultdict
import time

attempts = defaultdict(list)
MAX_ATTEMPTS = 10
WINDOW = 60  # seconds


def is_rate_limited(ip):
    now = time.time()
    attempts[ip] = [t for t in attempts[ip] if now - t < WINDOW]
    if len(attempts[ip]) >= MAX_ATTEMPTS:
        return True
    attempts[ip].append(now)
    return False


@app.route('/api/login', methods=['POST'])
def login():
    ip = request.remote_addr

    if is_rate_limited(ip):
        return jsonify({
            'success': False,
            'message': 'Too many attempts. Please wait before trying again.'
        }), 429

    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request.'}), 400

    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if email == VALID_EMAIL and password == VALID_PASSWORD:
        return jsonify({
            'success': True,
            'flag': FLAG
        })

    return jsonify({
        'success': False,
        'message': 'Invalid credentials'
    })


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'}), 200


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
